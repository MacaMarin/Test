
$('#formReserva').on('submit', function (e) {
  e.preventDefault();
  const pelicula = $('#pelicula').val();
  const hora = $('#hora').val();
  const asientos = $('#asientos').val();

  if (!pelicula || !hora || !asientos) {
    alert("Completa todos los campos");
    return;
  }

  $('#confirmacion').removeClass('d-none').html(`
    <strong>✅ Reserva confirmada:</strong><br>
    🎥 Película: <span class="text-dark">${pelicula}</span><br>
    🕒 Hora: <span class="text-dark">${hora}</span><br>
    🎟️ Asientos: <span class="text-dark">${asientos}</span>
  `);

  const modal = bootstrap.Modal.getInstance(document.getElementById('reservaModal'));
  modal.hide();
});

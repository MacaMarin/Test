
const libros = [
 {
titulo: "El Principito",
autor: "Antoine de Saint-Exupéry",
genero: "Ficción",
resumen: "Una historia poética sobre un pequeño príncipe y sus viajes."
 },
 {
titulo: "Clean Code",
autor: "Robert C. Martin",
genero: "Programación",
resumen: "Una guía para escribir código limpio y mantenible."
 },
 {
titulo: "Cien Años de Soledad",
autor: "Gabriel García Márquez",
genero: "Realismo mágico",
resumen: "Una saga familiar ambientada en el mítico pueblo de Macondo."
 }
];


function buscarLibros() {
  const titulo = document.getElementById("titulo").value.toLowerCase();
  const autor = document.getElementById("autor").value.toLowerCase();
  const genero = document.getElementById("genero").value;

  const resultados = libros.filter(libro => {
    return (
      libro.titulo.toLowerCase().includes(titulo) &&
      libro.autor.toLowerCase().includes(autor) &&
      (genero === "" || libro.genero === genero)
    );
  });

  mostrarLibros(resultados);
}


function mostrarLibros(librosFiltrados) {
  const contenedor = document.getElementById("lista-libros");
  contenedor.innerHTML = "";

  librosFiltrados.forEach(libro => {
    const div = document.createElement("div");
    div.innerHTML = `
      <h3>${libro.titulo}</h3>
      <p><strong>Autor:</strong> ${libro.autor}</p>
      <p><strong>Género:</strong> ${libro.genero}</p>
      <p>${libro.resumen}</p>
    `;
    contenedor.appendChild(div);
  });
}

function validarFormulario() {
  const nombre = document.getElementById("nombre").value;
  const email = document.getElementById("email").value;
  const clave = document.getElementById("clave").value;

  if (!nombre || !email || !clave) {
    alert("Por favor, complete todos los campos.");
    return false;
  }

  alert("Registro exitoso. ¡Bienvenido a LibroLibre!");
  return true;
}
